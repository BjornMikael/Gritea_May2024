#this program says hello
#!/bin/sh

echo "Hello bosterma!"

